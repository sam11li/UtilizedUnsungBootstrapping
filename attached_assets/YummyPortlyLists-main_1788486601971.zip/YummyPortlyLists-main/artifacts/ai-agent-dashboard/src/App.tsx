import { useEffect, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import Overview from '@/pages/overview';
import Models from '@/pages/models';
import Memory from '@/pages/memory';
import Settings from '@/pages/settings';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
         <Route path="/" component={Overview} />
         <Route path="/models" component={Models} />
         <Route path="/memory" component={Memory} />
         <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  const [environment, setEnvironment] = useState<'VS Code' | 'Kali Linux' | null>(null);

  useEffect(() => {
    const stored = window.localStorage.getItem('agent-environment');
    if (stored === 'VS Code' || stored === 'Kali Linux') setEnvironment(stored);
  }, []);

  const chooseEnvironment = (value: 'VS Code' | 'Kali Linux') => {
    window.localStorage.setItem('agent-environment', value);
    setEnvironment(value);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
        {!environment && <EnvironmentChooser onChoose={chooseEnvironment} />}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

function EnvironmentChooser({ onChoose }: { onChoose: (value: 'VS Code' | 'Kali Linux') => void }) {
  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-sidebar/75 p-5 backdrop-blur-md" role="dialog" aria-modal="true" aria-labelledby="environment-title">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-6 shadow-2xl">
        <div className="mb-7">
          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary">Choose workspace</p>
          <h1 id="environment-title" className="mt-3 text-2xl font-extrabold tracking-[-0.04em]">Where do you want to work?</h1>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">Your choice sets the active workflow. Both environments use the same Replit API and shared agent memory.</p>
        </div>
        <div className="grid gap-3">
          <button onClick={() => onChoose('VS Code')} className="flex items-center justify-between rounded-2xl border border-border bg-background p-4 text-left transition-colors hover:border-primary/50 hover:bg-secondary" data-testid="button-environment-vscode">
            <span><span className="block text-sm font-extrabold">VS Code</span><span className="mt-1 block text-xs text-muted-foreground">Application development and coding</span></span>
            <span className="text-primary">→</span>
          </button>
          <button onClick={() => onChoose('Kali Linux')} className="flex items-center justify-between rounded-2xl border border-border bg-background p-4 text-left transition-colors hover:border-primary/50 hover:bg-secondary" data-testid="button-environment-kali">
            <span><span className="block text-sm font-extrabold">Kali Linux</span><span className="mt-1 block text-xs text-muted-foreground">Open Interpreter and security tooling</span></span>
            <span className="text-primary">→</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
